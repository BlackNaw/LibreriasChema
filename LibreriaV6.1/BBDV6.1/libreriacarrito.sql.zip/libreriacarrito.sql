-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2017 at 02:29 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `libreriacarrito`
--

-- --------------------------------------------------------

--
-- Table structure for table `tema`
--

CREATE TABLE `tema` (
  `tema` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tema`
--

INSERT INTO `tema` (`tema`) VALUES
('Acción'),
('Aventuras'),
('Biografía'),
('Ciencia'),
('Ciencia Ficción'),
('Cine'),
('Economía'),
('Gastronomía'),
('Historia'),
('Informática'),
('Medicina'),
('Misterio'),
('Naturaleza'),
('Policíaco'),
('Política'),
('Romántica'),
('Teatro'),
('Terror');

-- --------------------------------------------------------

--
-- Table structure for table `tfactura`
--

CREATE TABLE `tfactura` (
  `codFactura` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `usuario` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `fechaFactura` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `borrado` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tfactura`
--

INSERT INTO `tfactura` (`codFactura`, `usuario`, `fechaFactura`, `borrado`) VALUES
('cod001', 'user', '2017-03-07 14:30:02', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tlibro`
--

CREATE TABLE `tlibro` (
  `codLibro` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `titulo` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `autor` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `tema` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `paginas` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `formatouno` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `formatodos` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `formatotres` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `estado` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `precio` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tlibro`
--

INSERT INTO `tlibro` (`codLibro`, `titulo`, `autor`, `tema`, `paginas`, `formatouno`, `formatodos`, `formatotres`, `estado`, `precio`) VALUES
('cod001', 'El Quijote', 'Cervantes', 'Acción', '123', 'N/A', 'N/A', 'tapa-dura', 'reedicion', '29.99'),
('cod002', 'Java a Fondo', 'Ceballos', 'Informática', '86', 'N/A', 'rustica', 'N/A', 'novedad', '25.2'),
('cod003', 'El Diario de Anna Frank', 'Anna Frank', 'Historia', '123', 'N/A', 'rustica', 'N/A', 'novedad', '321');

-- --------------------------------------------------------

--
-- Table structure for table `tlineafactura`
--

CREATE TABLE `tlineafactura` (
  `codFactura` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `libro` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `cantidad` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `total` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tlineafactura`
--

INSERT INTO `tlineafactura` (`codFactura`, `libro`, `cantidad`, `total`) VALUES
('cod001', 'El Diario de Anna Frank', '3', '963'),
('cod001', 'El Quijote', '1', '29.99'),
('cod001', 'Java a Fondo', '2', '50.4');

-- --------------------------------------------------------

--
-- Table structure for table `tusuario`
--

CREATE TABLE `tusuario` (
  `codusuario` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `nick` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `rol` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `tusuario`
--

INSERT INTO `tusuario` (`codusuario`, `nick`, `pass`, `rol`) VALUES
('cod001', 'admin', 'admin', 'admin'),
('cod002', 'user', 'user', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tema`
--
ALTER TABLE `tema`
  ADD PRIMARY KEY (`tema`),
  ADD UNIQUE KEY `tema` (`tema`);

--
-- Indexes for table `tfactura`
--
ALTER TABLE `tfactura`
  ADD PRIMARY KEY (`codFactura`),
  ADD KEY `usuario` (`usuario`);

--
-- Indexes for table `tlibro`
--
ALTER TABLE `tlibro`
  ADD PRIMARY KEY (`codLibro`),
  ADD KEY `tema` (`tema`),
  ADD KEY `titulo` (`titulo`);

--
-- Indexes for table `tlineafactura`
--
ALTER TABLE `tlineafactura`
  ADD PRIMARY KEY (`codFactura`,`libro`),
  ADD KEY `libro` (`libro`);

--
-- Indexes for table `tusuario`
--
ALTER TABLE `tusuario`
  ADD PRIMARY KEY (`codusuario`),
  ADD UNIQUE KEY `nick` (`nick`),
  ADD KEY `nick_2` (`nick`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tlibro`
--
ALTER TABLE `tlibro`
  ADD CONSTRAINT `tlibro_ibfk_1` FOREIGN KEY (`tema`) REFERENCES `tema` (`tema`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
